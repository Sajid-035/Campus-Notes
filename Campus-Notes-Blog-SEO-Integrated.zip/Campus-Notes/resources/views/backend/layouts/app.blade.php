<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"
        name="viewport">
    <title>@yield('title') &mdash; Stisla</title>

    <!-- General CSS Files -->
    <link rel="stylesheet"
        href="{{ asset('backend/library/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer" />

    @stack('style')

    <!-- Template CSS -->
    <link rel="stylesheet"
        href="{{ asset('backend/css/style.css') }}">
    <link rel="stylesheet"
        href="{{ asset('backend/css/components.css') }}">

    <!-- Start GA -->
    <script async
        src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-94034622-3');
    </script>
    <!-- END GA -->
</head>
</head>

<body>
    <div id="app">
        <div class="main-wrapper">
            <!-- Header -->
            @include('backend.components.header')

            <!-- Sidebar -->
            @include('backend.components.sidebar')

            <!-- Content -->
            @yield('main')

            <!-- Footer -->
            @include('backend.components.footer')
        </div>
    </div>
 
    
    <!-- General JS Scripts -->
    <script src="{{ asset('backend/library/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('backend/library/popper.js/dist/umd/popper.js') }}"></script>
    <script src="{{ asset('backend/library/tooltip.js/dist/umd/tooltip.js') }}"></script>
    <script src="{{ asset('backend/library/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('backend/library/jquery.nicescroll/dist/jquery.nicescroll.min.js') }}"></script>
    <script src="{{ asset('backend/library/moment/min/moment.min.js') }}"></script>
    <script src="{{ asset('backend/js/stisla.js') }}"></script>
    <script src="{{ asset('backend/library/jquery-ui-dist/jquery-ui.min.js') }}"></script>
    @stack('scripts')

    <!-- Template JS File -->
    <script src="{{ asset('backend/js/scripts.js') }}"></script>
    <script src="{{ asset('backend/js/custom.js') }}"></script>
    
</body>

</html>
